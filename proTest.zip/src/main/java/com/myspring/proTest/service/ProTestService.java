package com.myspring.proTest.service;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface ProTestService {
	public List listMembers() throws DataAccessException;
}
