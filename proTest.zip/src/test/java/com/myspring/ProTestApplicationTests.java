package com.myspring;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
